def findR1(ACC, R0):
    """
    根据 R0 计算 R1 的值。

    参数:
    - ACC: 字典形式存储的阈值和对应的准确率。
    - R0: 第一个最大准确率对应的阈值。

    返回:
    - R1: 按规则计算得到的阈值。
    """
    # 将字典按阈值升序排序
    sorted_ACC = sorted(ACC.items())

    # 找到 R0 对应的索引位置
    thresholds = [threshold for threshold, _ in sorted_ACC]
    accuracies = [accuracy for _, accuracy in sorted_ACC]
    R0_index = thresholds.index(R0)

    # 如果 R0 是第一个阈值，R1 = R0
    if R0_index == 0:
        return R0

    # 查找 threshold1 ~ thresholdi-1 中最大的准确率
    max_accuracy = max(accuracies[:R0_index])

    # 找到所有最大准确率对应的阈值
    candidate_thresholds = [
        thresholds[j] for j in range(R0_index)
        if accuracies[j] == max_accuracy
    ]

    # 从候选中选择最大的阈值
    R1 = max(candidate_thresholds)
    return R1


def findR2(ACC, R0):
    """
    根据 R0 计算 R2 的值。

    参数:
    - ACC: 字典形式存储的阈值和对应的准确率。
    - R0: 第一个最大准确率对应的阈值。

    返回:
    - R2: 按规则计算得到的阈值。
    """
    # 将字典按阈值升序排序
    sorted_ACC = sorted(ACC.items())

    # 找到 R0 对应的索引位置
    thresholds = [threshold for threshold, _ in sorted_ACC]
    accuracies = [accuracy for _, accuracy in sorted_ACC]
    R0_index = thresholds.index(R0)

    # 如果 R0 是最后一个阈值，R2 = R0
    if R0_index == len(thresholds) - 1:
        return R0

    # 查找 thresholdi+1 ~ thresholdn 中最大的准确率
    max_accuracy = max(accuracies[R0_index + 1:])

    # 找到所有最大准确率对应的阈值
    candidate_thresholds = [
        thresholds[j] for j in range(R0_index + 1, len(thresholds))
        if accuracies[j] == max_accuracy
    ]

    # 从候选中选择最小的阈值
    R2 = min(candidate_thresholds)
    return R2




def caculateK(ACC,R0):

    # # 调用新的训练函数
    # R0= 12
    # ACC = {4: 0.88, 8: 0.88, 12: 1, 16: 0.8888888888888888, 20: 0.9888888888888888, 24: 0.7777777777777778, 28: 0.8888888888888888}

    # 输出所有准确率结果
    print("所有准确率结果:", ACC)

    # 输出第一个最大准确率对应的阈值
    print("第一个最大准确率对应的阈值 R0:", R0)

    # 计算并输出 R1
    R1 = findR1(ACC, R0)
    print("R1 的值:", R1)

    R2 = findR2(ACC, R0)
    print("R2 的值:", R2)

    k1=R1/R0
    k2=R2/R0

    return R1, R2, k1, k2