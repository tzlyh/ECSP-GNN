import glob
import numpy as np
import pandas as pd
from Bio.PDB import PDBParser
import os
import glob
import re

three_to_one = {
    'ALA': 'A', 'ARG': 'R', 'ASN': 'N', 'ASP': 'D', 'CYS': 'C', 'GLN': 'Q', 'GLU': 'E', 'GLY': 'G',
    'HIS': 'H', 'ILE': 'I', 'LEU': 'L', 'LYS': 'K', 'MET': 'M', 'PHE': 'F', 'PRO': 'P', 'SER': 'S',
    'THR': 'T', 'TRP': 'W', 'TYR': 'Y', 'VAL': 'V'}

def parse_pdb(file_path):
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure('protein', file_path)
    amino_acids = []
    coordinates = {}
    residue_numbers = []  # 存放所有氨基酸的序号的数组
    residue_names = []  # 存放所有氨基酸名称的数组
    for model in structure:
        for chain in model:
            for residue in chain:
                if residue.has_id('CA'):
                    amino_acids.append(residue)
                    residue_number = residue.get_id()[1]
                    residue_numbers.append(residue_number)  # 将序号添加到数组中
                    residue_name = residue.get_resname()  # 获取氨基酸名称
                    residue_names.append(three_to_one[residue_name])  # 将名称添加到数组中
                    a = len(amino_acids)
                    coordinates[a] = residue['CA'].coord
    # print("coordinates=",coordinates)
    return coordinates

def calculate_distance(coord1, coord2):
    return ((coord1[0] - coord2[0]) ** 2 + (coord1[1] - coord2[1]) ** 2 + (coord1[2] - coord2[2]) ** 2) ** 0.5

def calculate_distances_from_DxDD(coordinates, DxDD_positions):
    """
    计算序列中所有氨基酸到每个DxDD motif的最短距离，并返回所有距离和最远距离。
    """
    all_distances = []
    for motif in DxDD_positions:
        # 初始化motif中各个位置的坐标
        coords = []
        for pos in motif:
            coord = coordinates.get(pos)  # 获取对应位置的坐标
            coords.append(coord)

        # 如果motif中完全没有有效坐标，跳过
        if not coords:
            continue

        # 计算到motif中所有点的最短距离
        distances = []
        for _, coord in coordinates.items():
            min_dist = min(calculate_distance(coord, motif_coord) for motif_coord in coords)
            distances.append(min_dist)

        # 记录该motif的最大最短距离
        all_distances.append(max(distances))

    # 返回所有motif的距离列表和全局最大距离
    global_max_distance = max(all_distances) if all_distances else None
    return all_distances, global_max_distance


def read_excel(file_path):
    """
    读取 Excel 文件，获取 PDB 文件名列表。
    """
    df = pd.read_excel(file_path)
    pdb_file_names = df.iloc[:, 0].tolist()  # 假设第一列是 PDB 文件名
    return pdb_file_names

def find_DxDD_positions(df):

    pattern1 = r'DD\w\w([DE])'  # DDXX(D/E)
    pattern2 = r'(N|D)D\w\w(S|T)\w{3}([DE])'  # (N/D)DXX(S/T)XXX(D/E)

    patterns_info = []

    for sequence in df['Sequence']:
        matches_pattern1 = [pos for match in re.finditer(pattern1, sequence) for pos in
                            range(match.start(), match.end()) if ' ' not in sequence[match.start():match.end()]]
        matches_pattern2 = [pos for match in re.finditer(pattern2, sequence) for pos in
                            range(match.start(), match.end()) if ' ' not in sequence[match.start():match.end()]]
        patterns_info.append((matches_pattern1, matches_pattern2))

    return patterns_info


def create_data():
    """
    主函数：计算每个序列中所有氨基酸与 DxDD motif 的最远距离，并统计全局最小值。
    """
    excel_file_path = r"/mnt/c/Users/13103/hh-suite/data/test/aaa.xlsx"
    pdb_file_names = read_excel(excel_file_path)

    file_path = r"/mnt/c/Users/13103/hh-suite/data/test/all_sequences.txt"
    with open(file_path, 'r') as file:
        lines = file.readlines()

    data = {'Reaction': [], 'Sequence': []}
    for line in lines:
        parts = line.strip().split()
        reaction = int(parts[1])
        sequence = parts[2]
        data['Reaction'].append(reaction)
        data['Sequence'].append(sequence)

    df = pd.DataFrame(data)
    DxDD_positions = find_DxDD_positions(df)
    all_max_distances = []  # 用于记录所有序列的 max_distance

    for i, pdb_file_name in enumerate(pdb_file_names):
        pdb_file_path = f"/mnt/c/Users/13103/hh-suite/data/test/sesPDB/{pdb_file_name}.pdb"
        # print("pdb_file_name=",pdb_file_name)
        if not glob.glob(pdb_file_path):
            print(f"未找到 {pdb_file_name} 的 PDB 文件")
            continue

        # print(f"DxDD_positions[{i}]={DxDD_positions[i]}")

        coordinates = parse_pdb(pdb_file_path)
        _, max_distance = calculate_distances_from_DxDD(coordinates, DxDD_positions[i])
        print(f"序列 {pdb_file_name} 中氨基酸到 DxDD 的最远距离: {max_distance}")

        all_max_distances.append(max_distance)

    # 计算所有序列的 max_distance 中最小的值
    global_min_max_distance = min(all_max_distances)
    print(f"所有序列的 max_distance : {global_min_max_distance}")

    return all_max_distances, global_min_max_distance

def main():
    create_data()

if __name__ == "__main__":
    main()
