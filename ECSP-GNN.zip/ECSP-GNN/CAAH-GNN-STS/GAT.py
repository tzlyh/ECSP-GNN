import numpy as np
from sklearn.metrics import accuracy_score
from torch_geometric.nn import GATConv
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from makeGraph16_8A import create_data

# 定义GCN模型类
class GCNModel(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(GCNModel, self).__init__()
        self.conv1 = GATConv(in_channels, hidden_channels * 2)
        self.conv2 = GATConv(hidden_channels * 2, hidden_channels)
        self.conv3 = GATConv(hidden_channels, out_channels)

    def forward(self, x, edge_index):
        x = F.relu(self.conv1(x, edge_index))
        x = F.relu(self.conv2(x, edge_index))
        x = self.conv3(x, edge_index)
        x = x.mean(dim=0, keepdim=True)
        return x

def read_excel(file_path):
    df = pd.read_excel(file_path)
    pdb_file_names = df.iloc[:, 0].tolist()
    enzyme_labels = df.iloc[:, 1].tolist()
    return pdb_file_names, enzyme_labels

def train_test_split(data_list, labels, test_ratio=0.2):
    total_size = len(data_list)
    test_size = int(total_size * test_ratio)
    train_data = data_list[:-test_size]
    test_data = data_list[-test_size:]
    train_labels = labels[:-test_size]
    test_labels = labels[-test_size:]
    return train_data, train_labels, test_data, test_labels

def train_and_evaluate(data_list, labels, threshold_distance):
    train_data, train_labels, test_data, test_labels = train_test_split(data_list, labels)

    epochs = 100
    model = GCNModel(in_channels=1562, hidden_channels=64, out_channels=2)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    # 训练
    model.train()
    for epoch in range(epochs):
        for data, label in zip(train_data, train_labels):
            optimizer.zero_grad()
            output = model(data.x, data.edge_index)
            loss = F.cross_entropy(output, torch.tensor([label], dtype=torch.long))
            loss.backward()
            optimizer.step()

    # 测试
    model.eval()
    all_predictions = []
    with torch.no_grad():
        for data, label in zip(test_data, test_labels):
            output = model(data.x, data.edge_index)
            _, predicted = torch.max(output, 1)
            all_predictions.append(predicted.item())

    accuracy = accuracy_score(test_labels, all_predictions)
    print(f"Threshold Distance: {threshold_distance}, Test Accuracy: {accuracy:.4f}")
    return accuracy

def run_training_with_threshold(threshold_distance, excel_file_path):
    pdb_file_names, enzyme_labels = read_excel(excel_file_path)
    data_list = create_data(threshold_distance)
    accuracy = train_and_evaluate(data_list, enzyme_labels, threshold_distance)
    return accuracy
