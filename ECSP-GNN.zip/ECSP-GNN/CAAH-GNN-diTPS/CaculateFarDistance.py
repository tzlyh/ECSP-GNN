import glob
import numpy as np
import pandas as pd
from Bio.PDB import PDBParser

three_to_one = {
    'ALA': 'A', 'ARG': 'R', 'ASN': 'N', 'ASP': 'D', 'CYS': 'C', 'GLN': 'Q', 'GLU': 'E', 'GLY': 'G',
    'HIS': 'H', 'ILE': 'I', 'LEU': 'L', 'LYS': 'K', 'MET': 'M', 'PHE': 'F', 'PRO': 'P', 'SER': 'S',
    'THR': 'T', 'TRP': 'W', 'TYR': 'Y', 'VAL': 'V'}

def parse_pdb(file_path):
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure('protein', file_path)
    amino_acids = []
    coordinates = {}
    residue_numbers = []  # 存放所有氨基酸的序号的数组
    residue_names = []  # 存放所有氨基酸名称的数组
    for model in structure:
        for chain in model:
            for residue in chain:
                if residue.has_id('CA'):
                    amino_acids.append(residue)
                    residue_number = residue.get_id()[1]
                    residue_numbers.append(residue_number)  # 将序号添加到数组中
                    residue_name = residue.get_resname()  # 获取氨基酸名称
                    residue_names.append(three_to_one[residue_name])  # 将名称添加到数组中
                    a = len(amino_acids)
                    coordinates[a] = residue['CA'].coord
    # print("coordinates=",coordinates)
    return coordinates

def calculate_distance(coord1, coord2):
    return ((coord1[0] - coord2[0]) ** 2 + (coord1[1] - coord2[1]) ** 2 + (coord1[2] - coord2[2]) ** 2) ** 0.5

def calculate_distances_from_DxDD(coordinates, DxDD_position):
    """
    计算序列中所有氨基酸到 DxDD_position 的距离，并返回最远距离。
    """
    start_pos, middle_pos, end_pos = DxDD_position
    # print("DxDD_position",DxDD_position)
    start_coord = coordinates[start_pos + 1]
    middle_coord = coordinates[middle_pos + 1]
    end_coord = coordinates[end_pos + 1]

    distances = []
    for i, coord in coordinates.items():
        dist_to_start = calculate_distance(coord, start_coord)
        dist_to_middle = calculate_distance(coord, middle_coord)
        dist_to_end = calculate_distance(coord, end_coord)
        min_dist = min(dist_to_start, dist_to_middle, dist_to_end)
        # print("min_dist",min_dist)
        distances.append(min_dist)

    max_distance = max(distances)

    return distances, max_distance

def read_excel(file_path):
    """
    读取 Excel 文件，获取 PDB 文件名列表。
    """
    df = pd.read_excel(file_path)
    pdb_file_names = df.iloc[:, 0].tolist()  # 假设第一列是 PDB 文件名
    return pdb_file_names

def find_DxDD_positions(df):
    """
    在每个序列中查找 DxDD motif 的位置。
    """
    DxDD_positions = []
    for sequence in df['Sequence']:
        for i in range(len(sequence) - 3):
            if sequence[i] == 'D' and sequence[i + 2] == 'D' and sequence[i + 3] == 'D':
                DxDD_positions.append((i, i + 2, i + 3))
                break
    # print("DxDD_positions",DxDD_positions)
    return DxDD_positions

def create_data():
    """
    主函数：计算每个序列中所有氨基酸与 DxDD motif 的最远距离，并统计全局最小值。
    """
    excel_file_path = r"/mnt/c/Users/13103/hh-suite/data/test/new/all2.xlsx"
    pdb_file_names = read_excel(excel_file_path)

    file_path = r"/mnt/c/Users/13103/hh-suite/data/test/new/ProSeqs_Train2.txt"
    with open(file_path, 'r') as file:
        lines = file.readlines()

    data = {'Reaction': [], 'Sequence': []}
    for line in lines:
        parts = line.strip().split()
        reaction = int(parts[1])
        sequence = parts[2]
        data['Reaction'].append(reaction)
        data['Sequence'].append(sequence)

    df = pd.DataFrame(data)
    DxDD_positions = find_DxDD_positions(df)
    all_max_distances = []  # 用于记录所有序列的 max_distance

    for i, pdb_file_name in enumerate(pdb_file_names):
        pdb_file_path = f"/mnt/c/Users/13103/hh-suite/data/test/ditpsPDB/{pdb_file_name}.pdb"
        # print("pdb_file_name=",pdb_file_name)
        if not glob.glob(pdb_file_path):
            print(f"未找到 {pdb_file_name} 的 PDB 文件")
            continue

        coordinates = parse_pdb(pdb_file_path)
        _, max_distance = calculate_distances_from_DxDD(coordinates, DxDD_positions[i])
        print(f"序列 {pdb_file_name} 中氨基酸到 DxDD 的最远距离: {max_distance}")

        all_max_distances.append(max_distance)

    # 计算所有序列的 max_distance 中最小的值
    global_min_max_distance = min(all_max_distances)
    print(f"所有序列的 max_distance : {global_min_max_distance}")

    return all_max_distances, global_min_max_distance

def main():
    create_data()

if __name__ == "__main__":
    main()
