from CaculateFarDistance import create_data
from GAT import run_training_with_threshold
from findR import caculateK
from CAAH_GNN_diTPS import Micro_scaleAdaptiveSampling


def findMaxDistance():
    # 调用 create_data 获取所有序列的最远距离列表和最小的最远距离
    _, global_min_max_distance = create_data()

    # 取整数部分
    integer_part = int(global_min_max_distance)
    print(f"最小的最远距离的整数部分: {integer_part}")

    # 处理成小于该整数的最大的4的倍数
    largest_multiple_of_4 = (integer_part // 4) * 4
    print(f"小于 {integer_part} 的最大的4的倍数: {largest_multiple_of_4}")

    return largest_multiple_of_4


def EquidistantLayeredSampling(MaxDistance, excel_file_path):

    ACC = {}
    R0 = None  # 用于存储第一个最大准确率对应的阈值
    max_accuracy = float('-inf')  # 初始化最大准确率为负无穷
    current_threshold = 4

    # while current_threshold <= MaxDistance:
    while current_threshold <= 12:
        print(f"当前阈值: {current_threshold}")
        # 调用 GAT-MG 中的训练函数
        accuracy = run_training_with_threshold(current_threshold, excel_file_path)
        ACC[current_threshold] = accuracy  # 将阈值和对应的准确率存入字典

        # 检查是否是第一个最大准确率
        if accuracy > max_accuracy:
            max_accuracy = accuracy
            R0 = current_threshold

        current_threshold += 4  # 阈值递增 4

    return ACC, R0


if __name__ == "__main__":
    # 获取 MaxDistance
    MaxDistance = findMaxDistance()

    # 指定 Excel 文件路径
    excel_file_path = r"/mnt/c/Users/13103/hh-suite/data/test/all1.xlsx"

    # 调用新的训练函数
    ACC, R0 = EquidistantLayeredSampling(MaxDistance, excel_file_path)
    # 输出所有准确率结果
    print("所有准确率结果:", ACC)

    # 输出第一个最大准确率对应的阈值
    print("第一个最大准确率对应的阈值 R0:", R0)

    # R1, R2, k1, k2 = caculateK(ACC, R0)
    R1, R2, k1, k2 = map(float, caculateK(ACC, R0))
    R0 = float(R0)



    print(f"传之前，R0={R0},R1={R1},R2={R2},k1={k1},k2={k2}" )

    Micro_scaleAdaptiveSampling(R0, k1, k2)


